import numpy as np
import torch, os, json, io, cv2, time
from ultralytics import YOLO
from PIL import Image
import logging

INPUT_CONTENT_TYPE = 'image/jpeg'
OUTPUT_CONTENT_TYPE = 'application/json'
logger = logging.getLogger(__name__)

def model_fn(model_dir):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f'loading model on device: {device}')
    
    model = YOLO('/opt/ml/model/model.pt')
    return model

def input_fn(request_body, request_content_type):
    logger.info(f"Executing input_fn from inference.py ...")
    logger.info(f'request body : {request_body}')
    if request_content_type:
        pil_img = Image.open(io.BytesIO(request_body))
        np_img = np.array(pil_img)
        img = cv2.cvtColor(np_img, cv2.COLOR_RGB2BGR)
        #jpg_original = np.load(io.BytesIO(request_body), allow_pickle=True)
        #jpg_as_np = np.frombuffer(jpg_original, dtype=np.uint8)
        #img = cv2.imdecode(jpg_as_np, flags=-1)
    else:
        raise Exception("Unsupported content type: " + request_content_type)
    return img
    
def predict_fn(input_data, model):
    logger.info(f"Executing predict_fn from inference.py ...")
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    with torch.no_grad():
        result = model(input_data)
    return result
        
def output_fn(prediction_output, content_type):
    logger.info(f"Executing output_fn from inference.py ...")
    infer = {}
    for result in prediction_output:
        if 'boxes' in result.keys:
            infer['boxes'] = result.boxes.cpu().numpy().data.tolist()
        if 'masks' in result.keys:
            infer['masks'] = result.masks.cpu().numpy().data.tolist()
        if 'keypoints' in result.keys:
            infer['keypoints'] = result.keypoints.cpu().numpy().data.tolist()
        if 'probs' in result.keys:
            infer['probs'] = result.probs.cpu().numpy().data.tolist()
    return json.dumps(infer)

# import io
# import os
# import json
# import logging
# import torch
# from PIL import Image
# from ultralytics import YOLO

# INPUT_CONTENT_TYPE = 'image/jpeg'
# OUTPUT_CONTENT_TYPE = 'application/json'
# logger = logging.getLogger(__name__)


# def model_fn(model_dir: str):
#     device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#     logger.info(f'loading model on device: {device}')
#     logger.info(f'model list: {os.listdir(model_dir)}')
#     model = YOLO('/opt/ml/model/model.pt')
#     model.to(device)
#     #model.model.eval()
    
#     logger.info(f'model : {model}')
#     return model


# def input_fn(request_body, request_content_type=INPUT_CONTENT_TYPE):
#     logger.info('Serializing input.')
#     if request_content_type == INPUT_CONTENT_TYPE:
#         logger.info(f'requrest body : {request_body}')
#         return Image.open(io.BytesIO(request_body))
#     logger.info(f'Request content type : {request_content_type}')

    
# def predict_fn(input_data, model):
#     logger.info('Making prediction.')
    
#     with torch.no_grad():
#         result = model(input_data)
#     return result


# def output_fn(prediction_output, accept=OUTPUT_CONTENT_TYPE):
#     logger.info('Serializing the generated output.')
#     logger.info(f'prediction_output : {prediction_output}')
#     infer = {}
#     if accept == OUTPUT_CONTENT_TYPE:
#         for result in prediction_output:
#             if 'boxes' in result.keys:
#                 infer['boxes'] = result.boxes.numpy().data.tolist()
#             if 'masks' in result.keys:
#                 infer['masks'] = result.masks.numpy().data.tolist()
#             if 'keypoints' in result.keys:
#                 infer['keypoints'] = result.keypoints.numpy().data.tolist()
#             if 'probs' in result.keys:
#                 infer['probs'] = result.probs.numpy().data.tolist()
#         return json.dumps(infer)
#     raise Exception('Requested unsupported ContentType in Accept: ' + accept)